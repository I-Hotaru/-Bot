#LyriaBot#

A Discord bot to aid crews in the game Granblue Fantasy. Included Functionality
includes a search for gbf.wiki, look up character skills, and Guild Wars commands.

Dependencies: nodemw, discord.js, node-schedule.
Requires you to run on your own computer.

Available Commands:
[[term]] - searches gbf.wiki for the specified page, and returns the first result to the channel it was called in.

!choose - given a semicolon separated list, the bot will choose one of the given choices

!ask - Answers a yes or no question using a set of pre-determined answers.

!gwprelims - notifies everyone in the channel that the preliminaries for the Guild War event has started

!gwfinals - notifies everyone in the channel that the finals for the Guild War event has started

!skills [character] - lists the skills of the characters and their description
